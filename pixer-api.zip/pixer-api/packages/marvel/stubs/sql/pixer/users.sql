INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `is_active`, `shop_id`) VALUES
(1, 'admin', 'vendor@demo.com', NULL, '$2y$10$zl1gWpOujA6lARlGbP6ZpOvops76lv9c46rZCCKR/l6.ZbNS6pxwa', NULL, '2022-01-20 15:24:42', '2022-01-20 15:24:42', 1, NULL),
(3, 'Customer', 'customer@demo.com', NULL, '$2y$10$Th4h9IBHPhtgeY7AAz5ZtOLrCT.EEXjnP.r/YiKXQyrv4uWOwBHeu', NULL, '2022-02-02 11:00:07', '2022-02-02 11:00:07', 1, NULL),
(5, 'customer 2', 'customer1@demo.com', NULL, '$2y$10$72j4PzWJk56K3R92ixnFiOb6qvKi/59LD3nwHybK42mGBPqSSVAUK', NULL, '2022-05-11 05:46:04', '2022-05-11 05:46:04', 1, NULL),
(6, 'customer 3', 'customer2@demo.com', NULL, '$2y$10$.tHNeinDXbB5pS9QkYOTJeHhmhG.wjJFb9J0BsLANqa5b7iyIAHVa', NULL, '2022-05-11 07:20:42', '2022-05-11 07:20:42', 1, NULL);
