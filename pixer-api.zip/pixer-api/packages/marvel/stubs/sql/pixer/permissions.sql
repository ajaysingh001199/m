INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'super_admin', 'api', '2022-01-20 15:24:23', '2022-01-20 15:24:23'),
(2, 'customer', 'api', '2022-01-20 15:24:23', '2022-01-20 15:24:23'),
(3, 'store_owner', 'api', '2022-01-20 15:24:23', '2022-01-20 15:24:23'),
(4, 'staff', 'api', '2022-01-20 15:24:23', '2022-01-20 15:24:23');
